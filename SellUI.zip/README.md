#——————————⟩[ COMMANDS ]⟨——————————#
- /sell → buka GUI utama.
- /sell hand → jual item di tangan.
- /sell all → jual semua item serupa dengan item di tangan.
- /sell inv → jual semua item di inventory.
- /sell autosell → toggle auto-sell (otomatis jual saat farming/item pickup).
- /sell log → lihat riwayat penjualan pribadi.

#——————————⟩[ SOSIAL MEDIA ]⟨——————————#
- YouTube → @leaddev-ts
- Grup WA → s.id/togethersmpgrupwa
- WhatsApp → s.id/togethersmpowner

#——————————⟩[ DEPENDS ]⟨——————————#
- FormAPI
- EconomyAPI

#——————————⟩[ REQUEST ]⟨——————————#
- Yang Mau Request Plugin Lainnya, Bisa Chat Ke WhatsApp Diatas!